package sample;

import sample.Cliente;
import sample.Conta;

public class MainCliente {

    public static void main(String[] args) {
        Conta conta = new Conta(1234,4566);
        conta.depositar(3000);

        Cliente cliente = new Cliente();
        cliente.setConta(conta);
        cliente.setNome("Larissa");
        cliente.setCpf("061.322.259.86");

        System.out.println(cliente);
    }

}
