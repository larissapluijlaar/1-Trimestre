package sample;

import sample.Receita;

public class Main {
    public static void main(String[] args) {
        Receita receita = new Receita();
        receita.setNome("Bolo da Maria");
        receita.setDescricao("Foi a Lua que fez");
        receita.setIngrediente("Farinha", 300, "g");
        receita.setIngrediente("outros", 200, "g");
        System.out.println(receita);

    }

}
