package sample;

import java.util.ArrayList;
import java.util.List;

public class Receita {

    private String nome;
    private String descrição;
    private List<Ingredientes> ingredientes;


    public Receita(){
        ingredientes = new ArrayList<>();
    }

    public List<Ingredientes> getIngredientes(){
        return ingredientes;
    }

    public void setIngrediente(String nome, double qtde, String um){
        Ingredientes ingredientes2 = new Ingredientes();
        ingredientes2.setNome(nome);
        ingredientes2.setQtde(qtde);
        ingredientes2.setUm(um);
        ingredientes.add(ingredientes2);
    }

    public void setIngredientes(Ingredientes ingredientes){
        this.ingredientes = (List<Ingredientes>) ingredientes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descrição;
    }

    public void setDescricao(String descricao) {
        this.descrição = descricao;
    }

    @Override
    public String toString() {
        return "Receita" +
                "\nnome: " + nome +
                "\ndescricao: " + descrição+
                "\nIngredientes" + ingredientes
                ;
    }
}
