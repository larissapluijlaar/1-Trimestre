package sample;

import sample.Model.Endereço;

public class MainEndereço {

    public static void main(String[] args){

        Endereço endereço = new Endereço();
        Endereço.setRua("Rua Lino Pessoa");
        System.out.println("Rua: " + endereço.getRua());
        endereço.setBairro("Oficinas");
        System.out.println("Bairro: " + endereço.getBairro());
        endereço.setNúmero("Número: " + endereço.getNúmero())

    }

}
