package sample;

import sample.Model.Livro;

public class MainLivro{
    public static void main(String[] args) {

        Livro livro = new Livro();
        livro.setTitulo("Fazendo Meu Filme");
        livro.setAutora("Paula Pimenta");
        livro.setEditora("GUTENBERG");
        livro.setAno(2008);

        System.out.println(livro);
    }
}
