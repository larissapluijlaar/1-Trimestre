package sample;

public class Conta {

    //Atributos
    private double numAgencia;
    private double numConta;
    private double Saldo;

    public void depositar (double valo){
        this.Saldo += Valor;
    }
    public double sacar ( double valor){
        if(valor <= Saldo){
            Saldo -= valor;
            return valor;
        }else{
            return 0;
        }
    }

    //getters and setters
    public double getNumAgencia() {
        return numAgencia;
    }

    public void setNumAgencia(double numAgencia) {
        this.numAgencia = numAgencia;
    }

    public double getNumConta() {
        return numConta;
    }

    public void setNumConta(double numConta) {
        this.numConta = numConta;
    }

    public double getSaldo() {
        return Saldo;
    }

    //toString
    @Override
    public String toString() {
        return "Conta: " +
                "Agencia:" + numAgencia +
                ", Conta corrente:" + numConta +
                ", Saldo:" + Saldo;
    }

}
