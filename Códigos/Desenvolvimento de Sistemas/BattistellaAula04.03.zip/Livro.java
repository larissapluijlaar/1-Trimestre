package sample.Model.;

public class Livro{
    //Atributos
    private String título;
    private String autora;
    private String editora;
    private int ano;

    public String getTitulo() {
        return título;
    }

    public void setTitulo(String titulo) {
        this.título = titulo;
    }

    public String getAutora() {
        return autora;
    }

    public void setAutora(String autora) {
        this.autora = autora;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public String toString() {
        return "Livro:" +
                "tÍtulo='" + título + '\'' +
                ", autora='" + autora + '\'' +
                ", editora='" + editora + '\'' +
                ", ano=" + ano;
    }
}
