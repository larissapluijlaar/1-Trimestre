package sample;

import sample.Cliente;

public class MainCliente {

    public class MainCliente {
        public static void main(String [] args){
            Cliente cliente = new Cliente();

            cliente.setNome("Larissa");
            cliente.setEmail("larissa_pluijlaar@estudante.sc.senai.br");
            cliente.setTelefone("(48) 99640-2180");
            cliente.setIdade(17);

            System.out.println(cliente);
        }

    }

}
