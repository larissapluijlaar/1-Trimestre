package sample.Model;

public class Endereço {

    //Atributos
    private String Rua;
    private String Bairro;
    private int Número;
    private String Cidade;

    public String getRua(){
        return Rua;
    }

    public void setRua(String rua){
        this.Rua = rua;
    }

    public String getBairro(){
        return Bairro;
    }

    public void setBairro(String Bairro){
        this.Bairro = Bairro;
    }

    public int getNúmero() {
        this.Número = Número;
    }

    public void setNúmero(){
        return Número;
    }

}
