package sample;

public class Main{
    public static void main(String[] args) {

        Conta conta = new Conta();
        conta.setNumAgencia(687495);
        conta.setNumConta(0326);
        conta.depositar(100);
        conta.sacar(25);
        System.out.println(conta);

    }
}
