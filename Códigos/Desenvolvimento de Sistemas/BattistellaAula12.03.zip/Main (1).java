package sample;

import sample.Tabuleiro;

import java.util.ArrayList;
import java.util.List;

public class Main{

    public static void main(String[] args) {
        List<String> nomes =
                new ArrayList<>();
        nomes.add("Carlos");
        nomes.add("Larissa");
        nomes.add("Senna");
        nomes.add("Ary");
        nomes.add("Fernando");
        nomes.add("Felipe");
        nomes.add("Pamêla");

        Tabuleiro tabuleiro =
                new Tabuleiro(nomes);

        tabuleiro.jogar();
        System.out.println(tabuleiro);

    }

}
