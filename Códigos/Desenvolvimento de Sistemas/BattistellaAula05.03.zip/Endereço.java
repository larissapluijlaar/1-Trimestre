package sample;

public class Endereço {

    private String Rua;
    private int Número;
    private String Bairro;
    private String Cidade;

    public String getRua() {
        return Rua;
    }

    public void setRua(String rua) {
        this.Rua = rua;
    }

    public int getNumero() {
        return Número;
    }

    public void setNumero(int numero) {
        this.Número = numero;
    }

    public String getBairro() {
        return Bairro;
    }

    public void setBairro(String bairro) {
        this.Bairro = bairro;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String cidade) {
        this.Cidade = cidade;
    }

    @Override
    public String toString() {
        return "Rua: "+ Rua + ", nº " + Número
                + " Bairro: " + Bairro + ", Cidade: "
                + Cidade;
    }
}
