package sample;

public class Pessoa {

    private String nome;
    private String dataNascimento;
    private Endereço endereço;

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getDataNascimento() {
        return dataNascimento;
    }
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    public Endereço getEndereco(){
        return this.endereço;
    }
    public void setEndereco(Endereço endereco){
        this.endereço = endereco;
    }
    public void setEndereco(String rua, int numero, String bairro, String cidade){
        Endereço endereco = new Endereço();
        endereco.setRua(rua);
        endereco.setNumero(numero);
        endereco.setBairro(bairro);
        endereco.setCidade(cidade);
        this.setEndereco(endereco);
    }

    @Override
    public String toString() {
        return "Nome: " + this.nome
                + ", Nascimento: " + dataNascimento + "\n"
                + "Endereço: " + endereço;
    }
}
