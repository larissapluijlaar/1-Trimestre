package sample;

import sample.Endereço;
import sample.Pessoa;

public class MainPessoaEndereço {

    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Carlos");
        pessoa.setDataNascimento("03/06/2004");
        Endereço endereco = new Endereço();
        endereco.setRua("Sete de setembro");
        endereco.setNumero(109);
        endereco.setBairro("Centro");
        endereco.setCidade("Florianópolis");

        pessoa.setEndereço(Endereço);

        System.out.println(pessoa);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Larissa");
        pessoa2.setDataNascimento("26/12/2003");
        pessoa2.setEndereco("Av. do Arquipelago", 300, "Vargem do Bom Jesus", "Florianópolis");
        System.out.println(pessoa2);

    }

}
