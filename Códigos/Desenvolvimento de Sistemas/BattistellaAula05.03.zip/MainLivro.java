package sample;

import sample.Livro;

public class MainLivro {

    public static void main(String[] args) {

        Livro livro = new Livro();

        livro.setTitulo("Crepúsculo");
        System.out.println("Título: " + livro.getTitulo());

        livro.setAutor("Stephenie Meyer");
        System.out.println("Autor: " + livro.getAutor());
        livro.setEditora("Intrínseca");
        System.out.println("Editora: " + livro.getEditora());
        livro.setAno(2005);
        System.out.println("Ano: " + livro.getAno());

        System.out.println("\n\n " + livro);

    }
}
