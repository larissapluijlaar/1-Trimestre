package sample;

import sample.Pessoa;

import java.util.ArrayList;
import java.util.List;

public class MainPessoa {

    public static void main(String []args){
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Gabriela");
        pessoa.setDataNascimento("04/03/2005");

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Ariany");
        pessoa2.setDataNascimento("11/10/2005");

        Pessoa pessoa3 = new Pessoa();
        pessoa3.setNome("anna");
        pessoa3.setDataNascimento("17/06/2004");

        List<Pessoa> pessoas = new ArrayList<>();
        pessoas.add(pessoa);
        pessoas.add(pessoa2);
        pessoas.add(pessoa3);
        System.out.println(pessoas);

        Pessoa pessoa4 = new Pessoa();
        pessoa4.setNome("Luan");
        pessoa4.setDataNascimento("27/06/2003");

        pessoas.add(pessoa4);
        System.out.println(pessoas);
    }
}
