package sample;

import sample.Endereço;

public class MainEndereço {

        public static void main(String[] args) {
            Endereço Endereço = new Endereço();
            Endereço.setRua("Av. do Arquipelago");
            Endereço.setNumero(300);
            Endereço.setBairro("Vargem do bom Jesus");
            Endereço.setCidade("Florianópolis");

            System.out.println(Endereço);
        }
    }
