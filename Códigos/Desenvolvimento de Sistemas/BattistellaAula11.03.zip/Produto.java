package sample;

public class Produto {

    private String Nome;
    private double Preço;

    public String getNome() {
        return Nome;
    }
    public void setNome(String nome) {
        this.Nome = nome;
    }
    public double getPreço() {
        return Preço;
    }
    public void setPreço(double preço) {
        this.Preço = preço;
    }

    @Override
    public String toString() {
        return "Produto: " +
                Nome +
                ", preço R$" + Preço;
    }
}
