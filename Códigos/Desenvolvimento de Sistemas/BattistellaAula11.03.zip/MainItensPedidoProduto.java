package sample;

import sample.ItensDoPedido;
import sample.Pedido;
import sample.Produto;

public class MainItensPedidoProduto {

    public static void main(String[] args) {
           //
          //ItensDoPedido itensDoPedido = new ItensDoPedido();
          //
          //Produto produto = new Produto();
          //Produto.setNome("Laranja");
          //Produto.setPreco(2.4);
          //ItensDoPedido.setProduto(Produto);
          //
          //ItensDoPedido.setProduto("Uva", 4.7);
          //System.out.println(itensDoPedido);

        Pedido pedido = new Pedido();
        pedido.setDesc("iFood");
        pedido.setData("11/3/21");
        pedido.addProduto("Uva", 5.4);
        pedido.addProduto("Laranja", 2.6);
        pedido.addProduto("Banana", 1.6);

        System.out.println(pedido);
    }
}
