package sample;

public class Pessoa {

    //Atributos
    private String Nome;
    private Contato Contato;

    public Pessoa(String nome){
        this.Nome = nome;
        Contato = new Contato();
    }

    //getters e setters
    public String getNome() {
        return Nome;
    }
    public Contato getContato() {
        return Contato;
    }
    public void setContato(String whatsapp, String email, String twitter){
        Contato.setWhatsapp(whatsapp);
        Contato.setTwitter(twitter);
        Contato.setEmail(email);
    }

    public void setNome(String nome) {
        this.Nome = nome;
    }
    //toString
    @Override
    public String toString(){
        return "Nome: " + this.Nome + ", " + Contato;
    }
}
