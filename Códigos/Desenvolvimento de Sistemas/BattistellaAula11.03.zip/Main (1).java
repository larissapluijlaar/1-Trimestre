package sample;

import sample.Pessoa;

public class Main{

    public static void main(String[] args){
        Pessoa pessoa = new Pessoa("Larissa");
        pessoa.setContato("4899640-2180",
                "larissapluijlaar@gmail.com","larispluijlaar");
        System.out.println(pessoa);
    }

}
