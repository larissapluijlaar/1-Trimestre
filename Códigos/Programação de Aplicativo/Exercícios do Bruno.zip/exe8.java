package sample;

public class exe8 {
    public static void main(String[] args) {
        int[] vetorA = {1,2,3,4,5,6,7,8,9,10};
        int[] vetorB = new int[5];
        int[] vetorC = new int[5];
        int b = 0;
        int c = 0;
        for (int i = 0; i<vetorA.length;i++){
            if (vetorA[i]%2 == 0){

                vetorB[b] = vetorA[i];
                b++;
            }

        }

        for (int i = 0; i<vetorB.length; i++){
            vetorC[i] = (vetorA[i]+vetorB[i]);
        }
        System.out.println("Vetor A");
        for (int i = 0; i<vetorA.length;i++){
            System.out.print(vetorA[i]+" ");
        }
        System.out.println("\n");

        System.out.println("Vetor B");
        for (int i =0;i<5;i++){

            System.out.print(vetorB[i]+" ");

        }
        System.out.println("\n");
        System.out.println("Vetor C ");
        for (int i =0;i<5;i++){

            System.out.print(vetorC[i]+ " ");

        }
    }
}
