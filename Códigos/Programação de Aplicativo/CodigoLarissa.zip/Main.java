class Main {
  public static void main(String[] args) {
    

    //Exercicio 1
    double p1 = 5.4;
    double p2 = 2.6;
    double media = (p1 + p2)/2;

    if(media >= 6){
      System.out.println("Você foi aprovado!");
    }
    else if(media < 6){
      System.out.println("Você foi para exame");

      double notaExame = 8.2;
      double novaMedia = (media + notaExame)/2;

      if(novaMedia >= 6){
        System.out.println("Você foi aprovado no exame");
      }
      else{
        System.out.println("Você foi reprovado");
      }
    }
    
    //Exercicio 2
    int idadeNadador = 29;

    if(idadeNadador <= 10){
      System.out.println("Infantil");
    }
    else if(idadeNadador <= 13){
      System.out.println("Infanto Juvenil");
    }
    else if (idadeNadador <= 18){
      System.out.println("Juvenil");
    }
    else if (idadeNadador > 18){
      System.out.println("Adulto");
    }

    //Exercicio 3
    int codigoItem1 = 1;
    int codigoItem2 = 2;
    int codigoItem3 = 3;
    int codigoItem4 = 4;
    int codigoItem5 = 5;
    
    String nomeItem1 = "Cachorro-Quente";
    String nomeItem2 = "X-Salada";
    String nomeItem3 = "X-Bacon";
    String nomeItem4 = "Torrada Simples";
    String nomeItem5 = "Refrigerante";

    double precoItem1 = 4.00;
    double precoItem2 = 4.50;
    double precoItem3 = 5.00;
    double precoItem4 = 2.00;
    double precoItem5 = 1.50;

    double qtdItem1 = (precoItem1 * 3);
    double qtdItem2 = (precoItem2 * 2);
    double qtdItem3 = (precoItem3 * 5);
    double qtdItem4 = (precoItem4 * 3);
    double qtdItem5 = (precoItem5 * 4);
    
    System.out.println("O valor final da compra é: " + (qtdItem1 + qtdItem2 + qtdItem3 + qtdItem4 + qtdItem5) + " reais");

    //Exercicio 4
    int classificacaoA = 1;
    int classificacaoB = 2; 
    int classificacaoC = 3;
    int classificacaoD = 4;

    double valorItem1 = 10;
    int classificacaoItem1 = 3;

    if(classificacaoItem1 == 1){
      System.out.println("A peça recebeu 10% de desconto");
      System.out.println(valorItem1 * 0.90);
    }
    else if(classificacaoItem1 == 2){
      System.out.println("A peça recebeu 15% de desconto");
      System.out.println(valorItem1 * 0.85);
    }
    else if(classificacaoItem1 == 3){
      System.out.println("A peça recebeu 20% de desconto");
      System.out.println(valorItem1 * 0.80);
    }
    else if(classificacaoItem1  == 4){
      System.out.println("A peça recebeu 5% de acréscimo");
      System.out.println(valorItem1 * 1.05);
    }

    //Exercicio 5
    int numeroPositivo = 5;
    int numeroNegativo = -10;
    int qtdRepeticoes = 20;

    while(qtdRepeticoes <= 20){
      System.out.println((numeroPositivo + 10));
      System.out.println((nume))
    }


  }  
}