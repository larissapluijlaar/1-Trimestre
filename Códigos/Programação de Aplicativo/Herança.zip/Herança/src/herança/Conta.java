package herança;

public class Conta {
    //atributos
    private String nome;
    private int numero;
    private double saldo;
    
    //métodos
    public void deposito(double valor){
        setSaldo(getSaldo() + valor);
        //saldo += valor;
    }
    public void saque(double valor){
        setSaldo(getSaldo() - valor);
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
    
}
