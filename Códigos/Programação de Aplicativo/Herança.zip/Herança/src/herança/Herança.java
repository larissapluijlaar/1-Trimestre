package herança;
public class Herança {
    public static void main(String[] args) {
        
        Conta c = new Conta();
        
        
        ContaEmpresarial petr = new ContaEmpresarial();
        petr.setNome("");
        petr.emprestimo(1000);
    }    
}
